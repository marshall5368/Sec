const Imgae = ['source/tshirts/T-shirt_6-removebg-preview.png','source/bags2/bag_4-removebg-preview.png','source/jacket/jacket_3-removebg-preview.png','source/bags2/bag_3-removebg-preview.png','source/shouse/yellow.png','source/bags2/love.png','source/tshirts/3-removebg-preview.png']
var display = document.getElementById('Image')
var currentIndex = 0

function Changeimg(){
   display.style.opacity = 0
   display.style.translate = ('200px')
      setTimeout(function(){ 
         currentIndex = (currentIndex + 1) % Imgae.length
         display.src = Imgae[currentIndex]
         display.style.opacity= 1   
         display.style.translate = 0
         
      },400)
    
}
display.addEventListener('click', function() {
   Changeimg();
})

function Prev(){
   display.style.opacity = 0
   display.style.translate = ('-200px')

      setTimeout(function(){
         currentIndex = (currentIndex - 1) % Imgae.length
        
         
         display.style.opacity= 1   
         display.style.translate = 0
         if(currentIndex < 0){
            currentIndex = 5
           
         }else{
           display.src = "ource/tshirts/3-removebg-preview.png"
         } 
         
         display.src = Imgae[currentIndex]
      },400)
     
}
display.addEventListener('click', function() {
   Changeimg();
})
